package com.example.btl.utils;

import com.example.btl.model.Admin;

public class Utils {
    public static final String BASE_URL = "http://dknane.click/banhang/";
    public static Admin admin_current = new Admin();
}
